# -*- coding: utf-8 -*-
from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from app.core.config import settings

# M11：默认使用 SQLite 仅适用于开发调试。
# 生产环境应通过环境变量 DATABASE_URL 配置 PostgreSQL/MySQL 等生产级数据库。
engine = create_engine(
    settings.DATABASE_URL,
    connect_args={"check_same_thread": False} if "sqlite" in settings.DATABASE_URL else {}
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()

# M17：get_db 已迁移至 app.core.dependencies，请改用：
#     from app.core.dependencies import get_db
